﻿using System.Text;

namespace Day5
{
    class Day5
    {
        //=========Part 1=================
        //--2
        public static void TestDefensiveCode()
        {
            int X, Y;
            do
            {
                Console.Write("Enter X: ");
            }
            while (!int.TryParse(Console.ReadLine(), out X));
            
            do
            {
                Console.Write("Enter Y: ");
            }
            while (!int.TryParse(Console.ReadLine(), out Y) || Y <= 1);

            Console.WriteLine(X / Y);
        }
        //--9
        public static void SumAndMultiply(int num1, int num2, out int sum, out int product)
        {
            sum = num1 + num2;
            product = num1 * num2;
        }

        //--10
        public static void PrintStringNumberOfTimes(string str, int times = 5)
        {
            for (int i = 0; i < times; i++)
            {
                Console.WriteLine(str);
            }
        }

        //--13
        public static int SumArray(params int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr?.Length; i++)
            {
                sum += arr[i];
            }
            return sum;
        }
        public static void Main(string[] args)
        {
            //================= Part 1 =================
            #region Problem 1
            ////--1
            //try
            //{
            //    int num1, num2;
            //    do
            //    {
            //        Console.Write("Enter the first number: ");
            //    }
            //    while (!int.TryParse(Console.ReadLine(), out num1));

            //    do
            //    {
            //        Console.Write("Enter the second number: ");
            //    }
            //    while (!int.TryParse(Console.ReadLine(), out num2));

            //    Console.WriteLine(num1 / num2);
            //}
            //catch(DivideByZeroException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Operation complete");
            //}
            ////finally block:
            ////- Run whether an exception occurs or not.
            ////- We use it when we have a code we want to run whether an exception occurs or not 
            #endregion

            #region Problem 2
            ////--2
            //TestDefensiveCode();
            ////int.TryParse() check the user input if the format of this input valid return true else return false 
            #endregion

            #region Problem 3
            ////--3
            //int? number = null;

            //number = number ?? default;
            //number = null;
            ////HasValue: Check if the variable is null or not if null return false otherwise return true
            //if (number.HasValue)
            //{
            //    //Value: return the value of the variable if value is null throw an InvalidOperationException exception
            //    Console.WriteLine(number.Value);
            //}
            ////When trying to access Value on a null Nullable<T> an InvalidOperationException can be occurs 
            #endregion

            #region Problem 4
            ////--4
            //int[] arr = { 1, 2, 3, 4, 5 };
            //int index = 5;
            ////we must to check the index before access to avoid IndexOutOfRangeException
            ////Console.WriteLine(arr[index]);

            //if (index < arr.Length)
            //{
            //    Console.WriteLine(arr[index]);
            //}
            ////It is necessary to check array bounds before accessing elements to avoid IndexOutOfRangeException 
            #endregion

            #region Problem 5
            ////--5
            //int[,] arr = new int[3, 3];

            //for (int i = 0; i < arr.GetLength(0); i++)
            //{
            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        do
            //        {
            //            Console.Write($"Enter ({i + 1}, {j + 1}) element: ");
            //        }
            //        while (!int.TryParse(Console.ReadLine(), out arr[i, j]));
            //    }
            //}
            //Console.WriteLine();
            ////Each row sum
            //for (int i = 0; i < arr.GetLength(0); i++)
            //{
            //    int sum = 0;
            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        sum += arr[i, j];
            //    }
            //    Console.WriteLine($"Row ({i + 1}) sum: {sum}");
            //}
            //Console.WriteLine();
            ////Each column sum
            //for (int i = 0; i < arr.GetLength(1); i++)
            //{
            //    int sum = 0;
            //    for (int j = 0; j < arr.GetLength(0); j++)
            //    {
            //        sum += arr[j, i];
            //    }
            //    Console.WriteLine($"Column ({i + 1}) sum: {sum}");
            //}
            ////GetLength(dimension): Used to get length of speceific dimension
            ////GetLength(0) => get first dimension length
            ////GetLength(1) => get second dimension length 
            #endregion

            #region Problem 6
            ////--6
            //int rows;
            //do
            //{
            //    Console.Write("Enter the number of rows: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out rows));
            //int[][] arr = new int[rows][];

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    int rowSize;
            //    do
            //    {
            //        Console.Write($"Enter rows ({i + 1}) size: ");
            //    }
            //    while (!int.TryParse(Console.ReadLine(), out rowSize));
            //    arr[i] = new int[rowSize];
            //    for(int j = 0; j < rowSize; j++)
            //    {
            //        do
            //        {
            //            Console.Write($"Enter ({i + 1}, {j + 1}) element: ");
            //        }
            //        while (!int.TryParse(Console.ReadLine(), out arr[i][j]));
            //    }
            //}
            //Console.WriteLine();
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.Write($"Row {i + 1}:\t");
            //    for (int j = 0; j < arr[i].Length; j++)
            //    {
            //        Console.Write($"{arr[i][j]}\t");
            //    }
            //    Console.WriteLine();
            //}
            ////Jagged arrays: Memory is allocated as multiple independent blocks
            ////               one block for the outer array and one block for each inner array (row)

            ////Rectangular arrays: The memory for rectangular arrays is allocated as a single contiguous block 
            #endregion

            #region Problem 7
            ////--7
            //string? s = null!;
            //Console.Write("Enter string value: ");
            // string input = Console.ReadLine();
            //if (input != "")
            //{
            //    s = input;
            //}
            //Console.WriteLine(s ?? "null");
            ////What is the purpose of nullable reference types in C#?
            ////- To increase code safety, reduce null reference exceptions, and improve clarity by making nullability explicit. 
            #endregion

            #region Problem 8
            ////--8
            //int number = 7;
            //object obj1 = number;//Boxing

            //object obj2 = "Hello";
            //int x = 0;
            //if (obj2 is int)
            //{
            //    x = (int)obj2;//Unboxing
            //}
            //Console.WriteLine($"obj: {obj2}, x: {x}");
            ////Boxing and Unboxing impact performance due to heap allocations, runtime type checks, garbage collection overhead 
            #endregion

            #region Problem 9
            ////--9
            //int num1, num2, sum, product;
            //do
            //{
            //    Console.Write("Enter the first number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(),out num1));
            //do
            //{
            //    Console.Write("Enter the second number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(),out num2));

            //SumAndMultiply(num1, num2, out sum, out product);

            //Console.WriteLine($"Sum: {sum}");
            //Console.WriteLine($"Product: {product}");
            ////out parameters: Designed to allow return multiple values so we must pass it to method 
            #endregion

            #region Problem 10
            ////--10
            //PrintStringNumberOfTimes("Example 1");
            //Console.WriteLine();

            //PrintStringNumberOfTimes("Example 2", 3);
            //Console.WriteLine();

            ////Named parameters
            //PrintStringNumberOfTimes(times: 7, str: "Example 3");

            ////Why must optional parameters always appear at the end of a method's parameter list?
            ////- Clear and unambiguous method calls
            ////- Readable and maintainable code
            ////- Better compatibility with method overloading and named parameters 
            #endregion

            #region Problem 11
            ////--11
            ////int[]? nullArr = { 1, 2, 3, 4, 5, 6 };//First example when array is not null
            //int[]? nullArr = null;//Second example when array is null
            //for (int i = 0; i < nullArr?.Length; i++)
            //{
            //    Console.WriteLine(nullArr[i]);
            //}

            ////Null propagation operator:
            ////- Explicitly checking if the object is null
            ////- If the object is null the operator returns null instead of throwing a NullReferenceException 
            #endregion

            #region Problem 12
            ////--12
            //int day;
            //do
            //{
            //    Console.Write("Enter the day number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(),out day) || day < 1 || day > 7);

            //switch (day)
            //{
            //    case 1:
            //        Console.WriteLine("Monday");
            //        break;
            //    case 2:
            //        Console.WriteLine("Tuesday");
            //        break;
            //    case 3:
            //        Console.WriteLine("Wednesday");
            //        break;
            //    case 4:
            //        Console.WriteLine("Thursday");
            //        break;
            //    case 5:
            //        Console.WriteLine("Friday");
            //        break;
            //    case 6:
            //        Console.WriteLine("Saturday");
            //        break;
            //    case 7:
            //        Console.WriteLine("Sunday");
            //        break;
            //}
            ////We prefer switch when we have a multiple conditions based on single value 
            #endregion

            #region Problem 13
            ////--13
            //int[] arr = { 5, 15, 25 };
            //Console.WriteLine($"When passing array: {SumArray(arr)}");
            //Console.WriteLine($"When passing values: {SumArray(2, 4, 6, 8)}");

            ////Limitations of the params Keyword:
            ////- Must be the last parameter
            ////- Single params Parameter
            ////- Works only with array (Cannot be used withCollection types)
            ////- No overloading based solely on params
            ////- Affect on performance
            ////- All arguments passed must be the same type 
            #endregion

            //================= Part 2 =================
            #region Problem 1
            ////--1
            //int number;
            //do
            //{
            //    Console.Write("Enter number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(),out number) || number < 1);

            //Console.Write("[ ");
            //for (int i = 1; i < number; i++)
            //{
            //    Console.Write($"{i}, ");
            //}
            //Console.Write(number);
            //Console.WriteLine(" ]"); 
            #endregion

            #region Problem 2
            //--2
            //int number;
            //do
            //{
            //    Console.Write("Enter number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out number));

            //Console.Write("[ ");
            //for (int i = 1; i < 12; i++)
            //{
            //    Console.Write($"{i * number}, ");
            //}
            //Console.Write(number * 12);
            //Console.WriteLine(" ]"); 
            #endregion

            #region Problem 3
            ////--3
            //int number;
            //do
            //{
            //    Console.Write("Enter number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out number));

            ////First solution for only positive numbers
            //Console.Write("[ ");
            //for (int i = 1; i < number; i++)
            //{
            //    if (i % 2 == 0)
            //    {
            //        if (i + 1 != number)
            //        {
            //            Console.Write($"{i}, ");
            //        }
            //        else
            //        {
            //            Console.Write(i);
            //        }
            //    }
            //}
            //if (number > 1 && number % 2 == 0)
            //{
            //    Console.Write(number);
            //}
            //Console.WriteLine(" ]");

            ////Second solution for all numbers (Print the even numbers from 1 to number)
            //int update = number < 0 ? -1 : 1;
            //Console.Write("[ ");
            //for (int i = 1; i != number; i += update)
            //{
            //    if (i % 2 == 0)
            //    {
            //        if (i + update != number)
            //        {
            //            Console.Write($"{i}, ");
            //        }
            //        else
            //        {
            //            Console.Write(i);
            //        }
            //    }
            //}
            //if (number % 2 == 0)
            //{
            //    Console.Write(number);
            //}
            //Console.WriteLine(" ]"); 
            #endregion

            #region Problem 4
            ////--4
            //int num1, num2;
            //do
            //{
            //    Console.Write("Enter the first number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out num1));
            //do
            //{
            //    Console.Write("Enter the second number: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out num2));

            //int result = 1;
            //for (int i = 0; i < num2; i++)
            //{
            //    result *= num1;
            //}
            //Console.WriteLine(result);

            ////Or we can use class Math with built in function Pow
            //Console.WriteLine(Math.Pow(num1, num2)); 
            #endregion

            #region Problem 6
            ////--5
            //Console.Write("Enter the text: ");
            //string text = Console.ReadLine();
            //for (int i = text.Length - 1; i >= 0; i--)
            //{
            //    Console.Write(text[i]);
            //} 
            #endregion

            #region Problem 7
            ////--7
            //int number;
            //do
            //{
            //    Console.Write("Enter number: ");
            //}
            ////First solution by dividing
            //while (!int.TryParse(Console.ReadLine(), out number));

            //while (number != 0)
            //{
            //    Console.Write(number % 10);
            //    number /= 10;
            //}
            //Console.WriteLine();
            ////Second solution by convert from int to string
            //string s = number.ToString();
            //for (int i = s.Length - 1; i >= 0; i--)
            //{
            //    Console.Write(s[i]);
            //} 
            #endregion

            #region Problem 8
            ////--8
            //int size;
            //do
            //{
            //    Console.Write("Enter the number of elements: ");
            //}
            //while (!int.TryParse(Console.ReadLine(), out size) || size < 1);
            //int[] numbers = new int[size];

            //for (int i = 0; i < size; i++)
            //{
            //    do
            //    {
            //        Console.Write($"Enter {i + 1} element: ");
            //    }
            //    while (!int.TryParse(Console.ReadLine(), out numbers[i]));
            //}
            ////First solution with time complexity: O(N^2)
            //int maxDistance = 0;
            //for (int i = 0; i < size; i++)
            //{
            //    for (int j = i + 1; j < size; j++)
            //    {
            //        if (numbers[i] == numbers[j] && j - i > maxDistance)
            //        {
            //            maxDistance = j - i;
            //        }
            //    }
            //}
            //Console.WriteLine(maxDistance - 1);

            ////Second solution using Dictionary with time complexity: O(N)
            //maxDistance = 0;
            //Dictionary<int,int> numbersMap = new Dictionary<int,int>();
            //for (int i = 0; i < size; i++)
            //{
            //    if (numbersMap.ContainsKey(numbers[i]))
            //    {
            //        if (i - numbersMap[numbers[i]] > maxDistance)
            //        {
            //            maxDistance = i - numbersMap[numbers[i]];
            //        }
            //    }
            //    else
            //    {
            //        numbersMap.Add(numbers[i], i);
            //    }
            //}
            //Console.WriteLine(maxDistance - 1); 
            #endregion

            #region Problem 9
            ////--9
            //string text = Console.ReadLine();
            //string[] textArr = text.Split(" ");
            ////We use StringBuilder because string is immutable and we chenge the value in every iteration
            //StringBuilder sb = new StringBuilder();

            //for (int i = textArr.Length - 1; i >= 0; i--)
            //{
            //    sb.Append($"{textArr[i]} ");
            //}
            //Console.WriteLine(sb); 
            #endregion

        }
    }
}